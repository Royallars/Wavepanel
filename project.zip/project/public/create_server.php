<?php
require '../includes/auth.php';

if (!isAuthenticated()) {
    header('Location: login.php');
    exit;
}

// Placeholder for server creation logic
echo "Server creation feature coming soon!";
?>
