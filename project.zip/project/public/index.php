<?php
require '../includes/auth.php';

if (isAuthenticated()) {
    header('Location: dashboard.php');
    exit;
} else {
    header('Location: login.php');
    exit;
}
?>