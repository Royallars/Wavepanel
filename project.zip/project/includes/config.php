<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'panel');

// API Configuration
define('PTERODACTYL_URL', 'https://your-pterodactyl-panel.com');
define('PTERODACTYL_API_KEY', 'your-api-key');
?>
